// Guilherme Lorete Schmidt - 13676857
// Emanuel Percinio Goncalves de Oliveira - 13676878

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "registros_dados.h"
#include "funcoesAuxiliares.h"
#include "funcoesFornecidas.h"
#include "funcoes_arvore.h"
#include "subfuncoes_internas_arvore.h"

#ifndef FUNCIONALIDADES_ARVORES
#define FUNCIONALIDADES_ARVORES

void funcionalidade5();
void funcionalidade6();
void funcionalidade7();

#endif