// Guilherme Lorete Schmidt - 13676857
// Emanuel Percinio Goncalves de Oliveira - 13676878

#ifndef FUNCOES_AUXILIARES
#define FUNCOES_AUXILIARES

#include "registros_arvore.h"
#include "registros_dados.h"
#include "lista.h"

void concatena_chave(registro reg, char* string);
int open(FILE** arq, char* nome, char* mode);

#endif