// Guilherme Lorete Schmidt - 13676857
// Emanuel Percinio Goncalves de Oliveira - 13676878

#ifndef FUNCIONALIDADES
#define FUNCIONALIDADES

#include "registros_dados.h"
#include "funcoesAuxiliares.h"
#include "funcoesFornecidas.h"
#include "funcoes_dados.h"

// funcoes para cada funcionalidade criada

void funcionalidade1();
void funcionalidade2();
void funcionalidade3();
void funcionalidade4();

#endif