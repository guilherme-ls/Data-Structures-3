// Guilherme Lorete Schmidt - 13676857
// Emanuel Percinio Goncalves de Oliveira - 13676878

#ifndef FUNCIONALIDADES_GRAFO
#define FUNCIONALIDADES_GRAFO

#include "funcoesAuxiliares.h"

// Funcoes para cada funcionalidade criada

void funcionalidade8();
void funcionalidade9();
void funcionalidade10();
void funcionalidade11();
void funcionalidade12();

#endif